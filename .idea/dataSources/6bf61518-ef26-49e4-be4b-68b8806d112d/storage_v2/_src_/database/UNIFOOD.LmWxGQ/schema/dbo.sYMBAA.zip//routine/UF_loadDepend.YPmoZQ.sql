create function UF_loadDepend(@mainCode char(10), @groupid SMALLINT)
returns table as
return 
	select *
	from dbo.SANPHAM inner join dbo.ANKEM on dbo.ANKEM.MaDoAnKem = dbo.SANPHAM.MaSanPham
	where dbo.SANPHAM.MaNhom = @groupid and dbo.ANKEM.MaMonAnChinh = @mainCode
go

