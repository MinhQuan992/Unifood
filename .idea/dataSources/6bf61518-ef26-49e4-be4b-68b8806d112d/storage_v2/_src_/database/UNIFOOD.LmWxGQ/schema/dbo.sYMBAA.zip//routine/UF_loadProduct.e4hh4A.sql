create function UF_loadProduct()
returns table as 
return 
	select *
	from dbo.SANPHAM
go

