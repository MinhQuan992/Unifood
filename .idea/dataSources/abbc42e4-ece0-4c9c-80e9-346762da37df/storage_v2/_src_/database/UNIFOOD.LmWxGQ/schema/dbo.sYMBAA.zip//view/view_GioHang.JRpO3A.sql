----------------------------------------------------------------------------------------------------------------------------------------------

-- TẠO FUNCTION TÍNH GIÁ TRỊ ĐƠN HÀNG MÀ KHÁCH HÀNG ĐẶT (TRUYỀN VÀO MÃ ĐƠN HÀNG) --
-- NGUYỄN QUỐC NINH
-----------------------------------------------------------------------------------

-- TẠO TRIGGER CẬP NHẬT SỐ LƯỢNG HÀNG SAU KHI KHÁCH ĐẶT HÀNG HOẶC HỦY ĐƠN HÀNG (TRIGGER TRÊN BẢNG DONHANG) --
-- TẠ THỊ MAI HƯƠNG
-------------------------------------------------------------------------------------------------------------

-- TẠO VIEW GIỎ HÀNG BAO GỒM CÁC THÔNG TIN: MÃ GIỎ, MÃ NGƯỜI DÙNG, MÃ SẢN PHẨM VÀ SỐ LƯỢNG MỖI SẢN PHẨM --
--                          (GIỎ HÀNG CHƯA XUẤT HIỆN TRONG ĐƠN HÀNG)                                    --
-- TRẦN ĐĂNG TÂM
CREATE VIEW view_GioHang
AS
    SELECT g.MaGio, g.MaNguoiDung, d.MaSanPham, d.SoLuong
    FROM GIOHANG AS g INNER JOIN DATHANG AS d ON g.MaGio = d.MaGio
    WHERE g.MaGio NOT IN (SELECT MaGio FROM DONHANG)
go

