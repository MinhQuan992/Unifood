---------------------------------------------------------------

-- TẠO VIEW ĐƠN HÀNG --
-- VÕ TRẦN MINH QUÂN
CREATE VIEW view_DonHang AS
SELECT MaNguoiDung, MaDon, MaGiamGia, TT_DonHang, TT_ThanhToan, TongGiaTri, NgayDat, NgayGiaoHang, NgayThanhToan
FROM GIOHANG INNER JOIN DONHANG ON GIOHANG.MaGio = DONHANG.MaGio
go

