------------------------------------------------------------------------------

-- TẠO TRIGGER KIỂM TRA MÃ GIẢM GIÁ KHÁCH HÀNG CHỌN ĐÃ HẾT SỐ LƯỢNG HAY CHƯA, MÃ CÒN HIỆU LỰC KHÔNG VÀ MÃ CÓ THỂ ÁP DỤNG CHO GIỎ HÀNG KHÔNG --
-- VÕ TRẦN MINH QUÂN
CREATE TRIGGER trig_MaGiamGia
ON DONHANG
AFTER INSERT, UPDATE
AS
BEGIN
	DECLARE @maGiamGia VARCHAR(20)
	SELECT @maGiamGia = MaGiamGia
	FROM inserted
	IF @maGiamGia IS NOT NULL
	BEGIN
		DECLARE @soLuongMaConLai INT, @ngayBatDau DATE, @ngayKetThuc DATE, @giaTriToiThieu INT
		SELECT @soLuongMaConLai = SoLuong, @ngayBatDau = NgayBatDau, @ngayKetThuc = NgayKetThuc, @giaTriToiThieu = GTGH_ToiThieu
		FROM DONHANG DH INNER JOIN MAGIAMGIA GG ON DH.MaGiamGia = GG.TenMa
		IF @soLuongMaConLai = 0
		BEGIN
			PRINT N'Mã giảm giá bạn chọn đã hết số lượng'
			ROLLBACK TRAN
		END
		ELSE
		BEGIN
			DECLARE @homNay DATE
			SET @homNay = CONVERT(DATE, GETDATE())
			IF @homNay < @ngayBatDau
			BEGIN
				PRINT N'Mã giảm giá chưa có hiệu lực'
				ROLLBACK TRAN
			END
			ELSE
			BEGIN
				IF @homNay > @ngayKetThuc
				BEGIN
					PRINT N'Mã giảm giá đã hết hạn'
					ROLLBACK TRAN
				END
				ELSE
				BEGIN
					DECLARE @giaTriGioHang INT
					SELECT @giaTriGioHang = dbo.func_GiaTriGioHang(MaGio)
					FROM DONHANG
					IF @giaTriGioHang < @giaTriToiThieu
					BEGIN
						DECLARE @giaTriConThieu INT
						SET @giaTriConThieu = @giaTriToiThieu - @giaTriGioHang
						PRINT N'Giỏ hàng của bạn chưa đạt đủ giá trị tối thiểu để áp dụng mã giảm giá này!'
						PRINT N'Hãy mua thêm ít nhất ' + CONVERT(NVARCHAR, @giaTriConThieu) + N'VND để sử dụng mã giảm giá!'
						ROLLBACK TRAN
					END
				END
			END
		END
	END	
END
go

