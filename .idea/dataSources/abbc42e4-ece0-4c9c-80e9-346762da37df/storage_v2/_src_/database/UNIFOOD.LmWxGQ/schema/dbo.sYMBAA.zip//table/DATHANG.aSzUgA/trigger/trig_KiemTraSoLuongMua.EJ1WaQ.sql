-----------------------

-- TẠO VIEW CHI TIẾT ĐƠN HÀNG --
-- VÕ TRẦN MINH QUÂN

--------------------------------

-- TẠO TRIGGER KIỂM TRA THỜI GIAN HIỆU LỰC HỢP LỆ CỦA MÃ GIẢM GIÁ (NGÀY KẾT THÚC SAU NGÀY BẮT ĐẦU) --
-- TẠ THỊ MAI HƯƠNG
-----------------------------------------------------------------------------------------------------

-- TẠO TRIGGER KIỂM TRA SỐ LƯỢNG HÀNG MÀ KHÁCH HÀNG ĐẶT PHÙ HỢP VỚI TỔNG SỐ LƯỢNG HÀNG TRONG KHO HAY KHÔNG --
-- TRẦN ĐĂNG TÂM
CREATE TRIGGER trig_KiemTraSoLuongMua
ON DATHANG
AFTER INSERT, UPDATE
AS
BEGIN
	DECLARE @soLuongMua INT
	SELECT @soLuongMua = SoLuong
	FROM inserted

	DECLARE @soLuongConLai INT
	SELECT @soLuongConLai = SANPHAM.SoLuong
	FROM inserted INNER JOIN SANPHAM ON inserted.MaSanPham = SANPHAM.MaSanPham

	IF @soLuongMua > @soLuongConLai
	BEGIN
		PRINT N'Số lượng sản phẩm bạn đặt vượt quá số lượng trong kho!'
		ROLLBACK TRAN
	END
END
go

