
-- TẠO VIEW NGƯỜI DÙNG --
CREATE VIEW view_NguoiDung AS
SELECT MaNguoiDung, HoVaTen, GioiTinh, NgaySinh, DiaChi, DienThoai, Email
FROM NGUOIDUNG
go

