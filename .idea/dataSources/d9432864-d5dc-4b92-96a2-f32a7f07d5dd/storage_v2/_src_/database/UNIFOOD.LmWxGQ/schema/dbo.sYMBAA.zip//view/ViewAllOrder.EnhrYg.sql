CREATE view [dbo].[ViewAllOrder] as
select	DH.MaDon as MaDon, DH.HoVaTen as TenNguoiDung, 
		DH.DiaChi as DiaChi, 
		DH.DienThoai as PhoneNumber,
		dbo.USF_CountItemNumber(DH.MaGio) as Quantity,  
		dbo.USF_GetShippingUnitName(DH.MaDonViGiaoHang) as TenDonViGiaoHang, 
		DH.NgayDat as NgayDat, DH.NgayGiaoHang as NgayGiaoHang, DH.NgayThanhToan as NgayThanhToan, 
		DH.TongGiaTri as TongGiaTri, DH.TT_DonHang as TrangThaiDonHang, dbo.USF_GetPaymentStatus(DH.TT_ThanhToan) as TrangThaiThanhToan
from DONHANG DH
go

