
-- TẠO PROCEDURE TẠO VIEW VÀ PHÂN QUYỀN VIEW CHO KHÁCH HÀNG --
CREATE PROC proc_PhanQuyenViewChoKhachHang(@maNguoiDung VARCHAR(9))
AS
BEGIN
	DECLARE @tenView VARCHAR(100), @taoView VARCHAR(500), @phanQuyen VARCHAR(500)

	SET @tenView = 'view_NguoiDung' + @maNguoiDung
	SET @taoView = 'CREATE VIEW ' + @tenView + ' AS'
				   + CHAR(13) + 'SELECT * FROM NGUOIDUNG WHERE MaNguoiDung = ''' + @maNguoiDung + ''''
	SET @phanQuyen = 'GRANT SELECT, UPDATE(HoVaTen, GioiTinh, NgaySinh, DiaChi, DienThoai, Email, MatKhau) ON ' + @tenView + ' TO ' + @maNguoiDung
	EXEC(@taoView)
	EXEC(@phanQuyen)

	SET @tenView = 'view_GioHang' + @maNguoiDung
	SET @taoView = 'CREATE VIEW ' + @tenView + ' AS'
				   + CHAR(13) + 'SELECT * FROM GIOHANG WHERE MaNguoiDung = ''' + @maNguoiDung + ''''
	SET @phanQuyen = 'GRANT SELECT ON ' + @tenView + ' TO ' + @maNguoiDung
	EXEC(@taoView)
	EXEC(@phanQuyen)

	SET @tenView = 'view_DatHang' + @maNguoiDung
	SET @taoView = 'CREATE VIEW ' + @tenView + ' AS'
				   + CHAR(13) + 'SELECT MaGio, MaSanPham, SoLuong, GhiChu FROM DATHANG'
				   + CHAR(13) + 'WHERE MaGio IN (SELECT MaGio FROM view_GioHang' + @maNguoiDung + ')'
	SET @phanQuyen = 'GRANT SELECT, INSERT, DELETE, UPDATE ON ' + @tenView + ' TO ' + @maNguoiDung
	EXEC(@taoView)
	EXEC(@phanQuyen)

	SET @tenView = 'view_DonHang' + @maNguoiDung
	SET @taoView = 'CREATE VIEW ' + @tenView + ' AS'
				   + CHAR(13) + 'SELECT * FROM DONHANG'
				   + CHAR(13) + 'WHERE MaGio IN (SELECT MaGio FROM view_GioHang' + @maNguoiDung + ')'
	SET @phanQuyen = 'GRANT SELECT ON ' + @tenView + ' TO ' + @maNguoiDung
	EXEC(@taoView)
	EXEC(@phanQuyen)
END
go

