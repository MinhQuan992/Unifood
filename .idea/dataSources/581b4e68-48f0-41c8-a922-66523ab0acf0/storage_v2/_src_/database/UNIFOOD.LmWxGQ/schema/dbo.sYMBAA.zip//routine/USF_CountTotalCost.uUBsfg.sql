CREATE function USF_CountTotalCost(@CartCode int)
returns int 
as 
begin
	declare @res int
	select @res = sum(DH.DonGia*DH.SoLuong)
	from DATHANG DH 
	where DH.MaGio = @CartCode
	return @res
end

go

