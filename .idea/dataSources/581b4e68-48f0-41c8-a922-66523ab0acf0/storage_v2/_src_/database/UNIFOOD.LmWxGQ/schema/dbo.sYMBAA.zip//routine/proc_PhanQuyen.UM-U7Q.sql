--------------------------------

-- TẠO PROCEDURE PHÂN QUYỀN NGƯỜI DÙNG --
-- VÕ TRẦN MINH QUÂN
CREATE PROC proc_PhanQuyen(@maNguoiDung VARCHAR(9), @matKhau VARCHAR(50), @laQuanLy BIT)
AS
BEGIN
	DECLARE @taoNguoiDung VARCHAR(500), @themVaoRole VARCHAR(500), @role VARCHAR(10)
	IF @laQuanLy = 1
		SET @role = 'QuanLy'
	ELSE
		SET @role = 'KhachHang'
	SET @taoNguoiDung = 'CREATE LOGIN ' + @maNguoiDung + ' WITH PASSWORD = ''' + @matKhau + ''''
						+ CHAR(13) + 'CREATE USER ' + @maNguoiDung + ' FOR LOGIN ' + @maNguoiDung
	SET @themVaoRole = 'SP_ADDROLEMEMBER ''' + @role + ''', ''' + @maNguoiDung + ''''
	EXEC(@taoNguoiDung)
	EXEC(@themVaoRole)
END
go

