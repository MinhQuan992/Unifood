CREATE function USF_GetShippingUnitName(@ShippingCode nvarchar(10))
returns nvarchar(50)
as 
begin
	declare @res nvarchar(50)
	select @res = TenDonVi
	from DONVIGIAOHANG GH
	where GH.MaDonVi = @ShippingCode
	return @res
end

go

