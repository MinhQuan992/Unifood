--------------------------------------------------------------------

-- TẠO FUNCTION KIỂM TRA SỐ ĐIỆN THOẠI NGƯỜI DÙNG ĐÃ TỒN TẠI HAY CHƯA --
-- VÕ TRẦN MINH QUÂN
CREATE FUNCTION func_DienThoaiHopLe(@dienThoai VARCHAR(10))
RETURNS BIT
AS
BEGIN
	IF @dienThoai NOT IN (SELECT DienThoai FROM NGUOIDUNG)
		RETURN 1
	RETURN 0
END
go

