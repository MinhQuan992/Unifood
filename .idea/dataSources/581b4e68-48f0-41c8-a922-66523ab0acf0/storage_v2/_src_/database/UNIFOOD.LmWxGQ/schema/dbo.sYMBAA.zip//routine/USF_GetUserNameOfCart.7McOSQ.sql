CREATE function USF_GetUserNameOfCart(@CartCode int)
returns nvarchar(50)
as 
begin
	declare @res nvarchar(50)
	select @res = N.HoVaTen
	from GIOHANG G inner join NGUOIDUNG N on G.MaNguoiDung = N.MaNguoiDung
	where G.MaGio = @CartCode
	return @res
end

go

