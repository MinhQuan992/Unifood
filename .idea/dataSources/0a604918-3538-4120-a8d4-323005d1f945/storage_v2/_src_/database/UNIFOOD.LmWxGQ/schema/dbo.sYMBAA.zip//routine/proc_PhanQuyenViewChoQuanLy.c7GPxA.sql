-- TẠO PROCEDURE TẠO VIEW VÀ PHÂN QUYỀN VIEW CHO QUẢN LÝ --
CREATE PROC proc_PhanQuyenViewChoQuanLy(@maNguoiDung VARCHAR(9))
AS
BEGIN
	DECLARE @tenView VARCHAR(100), @taoView VARCHAR(500), @phanQuyen VARCHAR(500)
	SET @tenView = 'view_NguoiDung' + @maNguoiDung
	SET @taoView = 'CREATE VIEW ' + @tenView + ' AS'
				   + CHAR(13) + 'SELECT * FROM NGUOIDUNG WHERE MaNguoiDung = ''' + @maNguoiDung + ''''
	SET @phanQuyen = 'GRANT SELECT, UPDATE(HoVaTen, GioiTinh, NgaySinh, DiaChi, DienThoai, Email, MatKhau) ON ' + @tenView + ' TO ' + @maNguoiDung
	EXEC(@taoView)
	EXEC(@phanQuyen)
END
go

