------------------------------------------------------------------------

-- TẠO FUNCTION KIỂM TRA EMAIL NGƯỜI DÙNG ĐÃ TỒN TẠI HAY CHƯA --
-- VÕ TRẦN MINH QUÂN
CREATE FUNCTION func_EmailHopLe(@email VARCHAR(30))
RETURNS BIT
AS
BEGIN
	IF @email NOT IN (SELECT Email FROM NGUOIDUNG)
		RETURN 1
	RETURN 0
END
go

