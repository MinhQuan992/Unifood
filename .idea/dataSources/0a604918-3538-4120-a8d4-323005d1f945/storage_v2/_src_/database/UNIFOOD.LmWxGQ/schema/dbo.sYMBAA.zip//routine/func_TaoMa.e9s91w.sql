
-- TẠO FUNCTION SINH MÃ NGƯỜI DÙNG --
CREATE FUNCTION func_TaoMa(@tienTo VARCHAR(2))
RETURNS VARCHAR(9)
AS
BEGIN
	DECLARE @ketQua VARCHAR(9)
	DECLARE @maCuoiCung VARCHAR(9)
	SET @maCuoiCung = (SELECT TOP(1) MaNguoiDung 
					   FROM NGUOIDUNG
					   WHERE MaNguoiDung LIKE (@tienTo + '%')
					   ORDER BY MaNguoiDung DESC)
	SET @maCuoiCung = (SELECT SUBSTRING(@maCuoiCung, 3, 7))
	DECLARE @maSo INT
	SET @maSo = CONVERT(INT, @maCuoiCung)
	DECLARE @maMoi VARCHAR(7)
	SET @maMoi = CONVERT(VARCHAR(7), @maSo + 1)
	DECLARE @doDaiMaMoi INT
	SET @doDaiMaMoi = LEN(@maMoi)
	IF @doDaiMaMoi < 7
	BEGIN
		DECLARE @chuoiSo0 VARCHAR(6)
		SET @chuoiSo0 = '0'
		WHILE LEN(@chuoiSo0) < (7 - @doDaiMaMoi)
			SET @chuoiSo0 = @chuoiSo0 + '0'
		SET @ketQua = @tienTo + @chuoiSo0 + @maMoi
	END
	ELSE
		SET @ketQua = @tienTo + @maMoi
	RETURN @ketQua
END
go

