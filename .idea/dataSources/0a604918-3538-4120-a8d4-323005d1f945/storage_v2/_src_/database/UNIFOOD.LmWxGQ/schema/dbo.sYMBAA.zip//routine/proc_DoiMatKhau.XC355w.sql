-----------------------------------------

-- TẠO PROCEDURE ĐỔI MẬT KHẨU LOGIN --
-- VÕ TRẦN MINH QUÂN
CREATE PROC proc_DoiMatKhau(@maNguoiDung VARCHAR(9), @matKhau VARCHAR(50))
AS
BEGIN
	DECLARE @cauLenh VARCHAR(100)
	SET @cauLenh = 'ALTER LOGIN ' + @maNguoiDung + ' WITH PASSWORD = ''' + @matKhau + ''''
	EXEC(@cauLenh)
END
go

