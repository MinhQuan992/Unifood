
---- TẠO PROCEDURE PHÂN QUYỀN NGƯỜI DÙNG --
--CREATE PROC proc_PhanQuyen(@maNguoiDung VARCHAR(9), @matKhau VARCHAR(50), @laQuanLy BIT)
--AS
--BEGIN
--	DECLARE @taoNguoiDung VARCHAR(500), @role VARCHAR(10), @themVaoRole VARCHAR(100), @phanQuyenView VARCHAR(100)
--	IF @laQuanLy = 1
--		SET @role = 'QuanLy'
--	ELSE
--		SET @role = 'KhachHang'
--	SET @taoNguoiDung = 'CREATE LOGIN ' + @maNguoiDung + ' WITH PASSWORD = ''' + @matKhau + ''''
--						+ CHAR(13) + 'CREATE USER ' + @maNguoiDung + ' FOR LOGIN ' + @maNguoiDung
--	SET @themVaoRole = 'SP_ADDROLEMEMBER ''' + @role + ''', ''' + @maNguoiDung + ''''
--	SET @phanQuyenView = 'EXEC dbo.proc_PhanQuyenViewCho' + @role + ' ''' + @maNguoiDung + ''''
--	EXEC(@taoNguoiDung)
--	EXEC(@themVaoRole)
--	EXEC(@phanQuyenView)
--END
--GO

---- TẠO PROCEDURE ĐỔI MẬT KHẨU LOGIN --
--CREATE PROC proc_DoiMatKhau(@maNguoiDung VARCHAR(9), @matKhau VARCHAR(50))
--AS
--BEGIN
--	DECLARE @cauLenh VARCHAR(100)
--	SET @cauLenh = 'ALTER LOGIN ' + @maNguoiDung + ' WITH PASSWORD = ''' + @matKhau + ''''
--	EXEC(@cauLenh)
--END
--GO

--USE UNIFOOD
--GO
---- TẠO PROCEDURE TẠO VIEW VÀ PHÂN QUYỀN VIEW CHO QUẢN LÝ --
--CREATE PROC proc_PhanQuyenViewChoQuanLy(@maNguoiDung VARCHAR(9))
--AS
--BEGIN
--	DECLARE @tenView VARCHAR(100), @taoView VARCHAR(500), @phanQuyen VARCHAR(500)
--	SET @tenView = 'view_NguoiDung' + @maNguoiDung
--	SET @taoView = 'CREATE VIEW ' + @tenView + ' AS'
--				   + CHAR(13) + 'SELECT * FROM NGUOIDUNG WHERE MaNguoiDung = ''' + @maNguoiDung + ''''
--	SET @phanQuyen = 'GRANT SELECT, UPDATE(HoVaTen, GioiTinh, NgaySinh, DiaChi, DienThoai, Email, MatKhau) ON ' + @tenView + ' TO ' + @maNguoiDung
--	EXEC(@taoView)
--	EXEC(@phanQuyen)
--END
--GO

---- TẠO PROCEDURE TẠO VIEW VÀ PHÂN QUYỀN VIEW CHO KHÁCH HÀNG --
--CREATE PROC proc_PhanQuyenViewChoKhachHang(@maNguoiDung VARCHAR(9))
--AS
--BEGIN
--	DECLARE @tenView VARCHAR(100), @taoView VARCHAR(500), @phanQuyen VARCHAR(500)

--	SET @tenView = 'view_NguoiDung' + @maNguoiDung
--	SET @taoView = 'CREATE VIEW ' + @tenView + ' AS'
--				   + CHAR(13) + 'SELECT * FROM NGUOIDUNG WHERE MaNguoiDung = ''' + @maNguoiDung + ''''
--	SET @phanQuyen = 'GRANT SELECT, UPDATE(HoVaTen, GioiTinh, NgaySinh, DiaChi, DienThoai, Email, MatKhau) ON ' + @tenView + ' TO ' + @maNguoiDung
--	EXEC(@taoView)
--	EXEC(@phanQuyen)

--	SET @tenView = 'view_GioHang' + @maNguoiDung
--	SET @taoView = 'CREATE VIEW ' + @tenView + ' AS'
--				   + CHAR(13) + 'SELECT * FROM GIOHANG WHERE MaNguoiDung = ''' + @maNguoiDung + ''''
--	SET @phanQuyen = 'GRANT SELECT ON ' + @tenView + ' TO ' + @maNguoiDung
--	EXEC(@taoView)
--	EXEC(@phanQuyen)

--	SET @tenView = 'view_DatHang' + @maNguoiDung
--	SET @taoView = 'CREATE VIEW ' + @tenView + ' AS'
--				   + CHAR(13) + 'SELECT MaGio, MaSanPham, SoLuong, GhiChu FROM DATHANG'
--				   + CHAR(13) + 'WHERE MaGio IN (SELECT MaGio FROM view_GioHang' + @maNguoiDung + ')'
--	SET @phanQuyen = 'GRANT SELECT, INSERT, DELETE, UPDATE ON ' + @tenView + ' TO ' + @maNguoiDung
--	EXEC(@taoView)
--	EXEC(@phanQuyen)

--	SET @tenView = 'view_DonHang' + @maNguoiDung
--	SET @taoView = 'CREATE VIEW ' + @tenView + ' AS'
--				   + CHAR(13) + 'SELECT * FROM DONHANG'
--				   + CHAR(13) + 'WHERE MaGio IN (SELECT MaGio FROM view_GioHang' + @maNguoiDung + ')'
--	SET @phanQuyen = 'GRANT SELECT ON ' + @tenView + ' TO ' + @maNguoiDung
--	EXEC(@taoView)
--	EXEC(@phanQuyen)
--END
--GO

-- TẠO TRIGGER KHI CẬP NHẬT ĐƠN GIÁ SẢN PHẨM Ở BẢNG SẢN PHẨM --
CREATE TRIGGER trig_CapNhatDonGia
ON SANPHAM
AFTER UPDATE
AS
BEGIN
	DECLARE @maSanPham VARCHAR(10), @donGia INT
	SELECT @maSanPham = MaSanPHam, @donGia = DonGia
	FROM inserted

	UPDATE DATHANG
	SET DonGia = @donGia
	WHERE MaSanPham = @maSanPham AND MaGio NOT IN (SELECT MaGio FROM DONHANG)
END
go

