
-- TẠO TRIGGER KHI CẬP NHẬT ĐƠN GIÁ SẢN PHẨM Ở BẢNG SẢN PHẨM --
CREATE TRIGGER trig_CapNhatDonGia
ON SANPHAM
AFTER UPDATE
AS
BEGIN
	DECLARE @maSanPham VARCHAR(10), @donGia INT
	SELECT @maSanPham = MaSanPHam, @donGia = DonGia
	FROM inserted

	UPDATE DATHANG
	SET DonGia = @donGia
	WHERE MaSanPham = @maSanPham AND MaGio NOT IN (SELECT MaGio FROM DONHANG)
END
go

