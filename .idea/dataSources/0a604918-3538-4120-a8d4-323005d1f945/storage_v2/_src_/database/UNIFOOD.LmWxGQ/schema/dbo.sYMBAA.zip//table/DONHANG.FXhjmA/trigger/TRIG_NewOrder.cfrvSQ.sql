CREATE trigger TRIG_NewOrder
on dbo.DONHANG
after insert
as 
begin
	--first test: check number of item
	declare @num int
	select @num = count(*)
	from dbo.DATHANG DT inner join inserted i on i.MaGio = DT.MaGio
	where DT.SoLuong > dbo.USF_GetItemQuantity(DT.MaSanPham)
	if (@num>0) 
	begin
		rollback tran 
		print('Number of Product is not enough')
		return 
	end
	--second test: check bill date and order finish date
	declare @nowdate date 
	declare @billDate date
	declare @endDate date
	SELECT @nowdate = CAST( GETDATE() AS Date)
	select @billDate = i.NgayThanhToan, @endDate = i.NgayGiaoHang
	from inserted i
	if (@billDate < @nowdate OR @endDate < @nowdate)
	begin
		rollback tran
		print('Payment date and complete date must be bigger than placed date')
		return 
	end
	--third test: total cost must be right!
	declare @cost_real int
	declare @cost_bill int
	select @cost_bill = i.TongGiaTri, @cost_real = dbo.USF_CountTotalCost(i.MaGio) from inserted i
	if (@cost_bill<>@cost_real) 
	begin
		update dbo.DONHANG set TongGiaTri = @cost_real 
			where MaDon = (select i.MaDon from inserted i)
		print('The cost is not right, we have just corcted it!')
		return 
	end
	------------------------------------------------------------------------
	print('Ok! orfer is accepted!')
end
go

