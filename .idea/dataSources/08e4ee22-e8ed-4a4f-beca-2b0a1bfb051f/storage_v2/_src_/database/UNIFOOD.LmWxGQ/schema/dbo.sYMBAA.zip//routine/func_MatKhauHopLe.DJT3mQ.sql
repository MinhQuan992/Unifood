-------------------------------------

-- TẠO FUNCTION KIỂM TRA MẬT KHẨU CÓ ĐỘ DÀI TỪ 10 ĐẾN 50 KÍ TỰ--
-- VÕ TRẦN MINH QUÂN
CREATE FUNCTION func_MatKhauHopLe(@matKhau VARCHAR(50))
RETURNS BIT
AS
BEGIN
	DECLARE @doDaiMatKhau INT
	SET @doDaiMatKhau = LEN(@matKhau)
	IF @doDaiMatKhau < 10 OR @doDaiMatKhau > 50
		RETURN 0
	RETURN 1
END
go

