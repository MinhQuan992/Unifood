CREATE VIEW v_GioHangKhongCoTrongDonHang
AS
	SELECT g.MaGio, g.MaNguoiDung, d.MaSanPham, d.SoLuong
	FROM dbo.GIOHANG AS g
	JOIN dbo.DATHANG AS d
	ON g.MaGio = d.MaGio
	WHERE g.MaGio NOT IN (SELECT MaGio FROM dbo.DONHANG);
go

