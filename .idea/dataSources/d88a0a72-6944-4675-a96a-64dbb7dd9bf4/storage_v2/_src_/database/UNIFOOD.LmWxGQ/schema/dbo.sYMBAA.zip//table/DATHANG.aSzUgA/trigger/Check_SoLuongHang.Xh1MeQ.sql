
-- TẠO TRIGGER KIỂM TRA MẬT KHẨU CÓ ÍT NHẤT 8 KÍ TỰ --
-- NGUYỄN QUỐC NINH
------------------------------------------------------

-- TẠO TRIGGER KIỂM TRA THỜI GIAN HIỆU LỰC HỢP LỆ CỦA MÃ GIẢM GIÁ (NGÀY KẾT THÚC SAU NGÀY BẮT ĐẦU) --
-- TẠ THỊ MAI HƯƠNG
-----------------------------------------------------------------------------------------------------

-- TẠO TRIGGER KIỂM TRA SỐ LƯỢNG HÀNG MÀ KHÁCH HÀNG ĐẶT PHÙ HỢP VỚI TỔNG SỐ LƯỢNG HÀNG TRONG KHO HAY KHÔNG --
-- TRẦN ĐĂNG TÂM
CREATE TRIGGER Check_SoLuongHang 
ON dbo.DATHANG
AFTER INSERT, UPDATE
AS
	IF EXISTS (SELECT * 
			   FROM (-- Tổng số lượng hàng trong đơn hàng
					 SELECT MaSanPham, SUM(SoLuong) AS Sum_SoLuong
					 FROM dbo.DATHANG
					 GROUP BY MaSanPham
					) AS don
			   JOIN inserted AS ins
			   ON don.MaSanPham = ins.MaSanPham
			   JOIN (-- Tổng số lượng hàng trong kho
					 SELECT MaSanPham, SUM(SoLuong) AS Sum_SoLuong
					 FROM dbo.SANPHAM
					 GROUP BY MaSanPham
					) AS kho
			   ON kho.MaSanPham = don.MaSanPham
			   WHERE don.Sum_SoLuong > kho.Sum_SoLuong
			  )  
	BEGIN  
		RAISERROR ('Số lượng hàng được đặt lớn hơn số lượng hàng có trong kho', 16, 1);  
		ROLLBACK TRANSACTION;  
		RETURN   
	END;
go

