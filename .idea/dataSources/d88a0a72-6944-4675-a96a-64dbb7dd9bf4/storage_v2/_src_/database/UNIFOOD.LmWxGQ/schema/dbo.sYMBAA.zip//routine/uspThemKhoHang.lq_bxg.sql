CREATE PROCEDURE uspThemKhoHang
	@maKho CHAR(10),
	@tenKho NVARCHAR(50),
	@diaChi NVARCHAR(100)
AS
	--SET NOCOUNT ON
	INSERT INTO KHOHANG (MaKho, TenKho, DiaChi) VALUES (@maKho, @tenKho, @diaChi)

go

