
  create proc USP_LoadOrderList (@Num int) 
  as 
  begin
	select @Num = 1
  end
  go

